package com.cg.fms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="scheduler_details")
public class Scheduler 
{
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Scheduler_ID")
	public String schedulerId;
	@Column(name="Scheduler_Name")
	public String schedulerName;
	@Column(name="Scheduler_Contact")
	public String schedulerContact;
	@Column(name="Truck_Number")
	public String truckNumber;
	
	public Scheduler() {
		super();
	}
	
	public Scheduler(String schedulerName) 
	{
		super();
		this.schedulerName = schedulerName;
	}
	
	public Scheduler(String schedulerName, String schedulerContact) {
		super();
		this.schedulerName = schedulerName;
		this.schedulerContact = schedulerContact;
	}
	
	public Scheduler(String schedulerId, String schedulerName, String schedulerContact) 
	{
		super();
		this.schedulerId = schedulerId;
		this.schedulerName = schedulerName;
		this.schedulerContact = schedulerContact;
		
	}

	public String getSchedulerId() {
		return schedulerId;
	}

	public void setSchedulerId(String schedulerId) {
		this.schedulerId = schedulerId;
	}

	public String getSchedulerName() {
		return schedulerName;
	}

	public void setSchedulerName(String schedulerName) {
		this.schedulerName = schedulerName;
	}

	public String getSchedulerContact() {
		return schedulerContact;
	}

	public void setSchedulerContact(String schedulerContact) {
		this.schedulerContact = schedulerContact;
	}

	public String getTruckNumber() {
		return truckNumber;
	}

	public void setTruckNumber(String truckNumber) {
		this.truckNumber = truckNumber;
	}

	@Override
	public String toString() {
		return "Scheduler [schedulerId=" + schedulerId + ", schedulerName=" + schedulerName + ", schedulerContact="
				+ schedulerContact + ", truckNumber=" + truckNumber + "]";
	}
	
	
}
