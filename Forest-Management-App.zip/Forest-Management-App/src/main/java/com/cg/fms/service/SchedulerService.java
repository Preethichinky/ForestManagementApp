package com.cg.fms.service;

import java.util.List;

import com.cg.fms.dao.ISchedulerDao;
import com.cg.fms.dao.SchedulerDao;
import com.cg.fms.dto.Scheduler;

public class SchedulerService implements ISchedulerService
{
	ISchedulerDao dao = new SchedulerDao();
	
	//------------------------  Scheduler Application --------------------------//
		/*******************************************************************************************************
		 - Function Name	:	getScheduler
		 - Input Parameters	:	String schedulerId
		 - Return Type		:	schedulerId
		 - Author			:	Preethi
		 - Creation Date	:	29/10/2020
		 - Description		:	adding scheduler details to database calls dao method getScheduler(String schedulerId)
		 ********************************************************************************************************/
	
	public Scheduler getScheduler(String schedulerId) {
		// TODO Auto-generated method stub
		return dao.getScheduler(schedulerId);
	}

	//------------------------  Scheduler Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addScheduler
			 - Input Parameters	:	Scheduler scheduler
			 - Return Type		:	Scheduler 
			 - Author			:	Preethi
			 - Creation Date	:	29/10/2020
			 - Description		:	updating Scheduler details to database calls dao method addScheduler(Scheduler scheduler)
			 ********************************************************************************************************/	
	
	public boolean addScheduler(Scheduler scheduler) 
	{
		// TODO Auto-generated method stub
		String regex="[0-9]{10}";
		if(scheduler.getSchedulerContact().matches(regex))
		{
			return dao.addScheduler(scheduler);
		}
		else
		{
			return false;
		}
	}

	//------------------------  Scheduler Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	updateScheduler
	 - Input Parameters	:	Scheduler scheduler
	 - Return Type		:	Scheduler 
	 - Author			:	Preethi
	 - Creation Date	:	29/10/2020
	 - Description		:	updating Scheduler details to database calls dao method updateScheduler(Scheduler scheduler)
	 ********************************************************************************************************/	
	
	public boolean updateScheduler(Scheduler scheduler) 
	{
		// TODO Auto-generated method stub
		if(scheduler.getSchedulerId()!=null)
		{
			return dao.updateScheduler(scheduler);
		}
		else
		{
			return false;
		}
	}

	//------------------------  Scheduler Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	deleteScheduler
		 - Input Parameters	:	String schedulerId
		 - Return Type		:	schedulerId 
		 - Author			:	Preethi
		 - Creation Date	:	29/10/2020
		 - Description		:	updating Scheduler details to database calls dao method deleteScheduler(String schedulerId)
		 ********************************************************************************************************/
	
	public boolean deleteScheduler(String schedulerId) {
		// TODO Auto-generated method stub
		return dao.deleteScheduler(schedulerId);
	}

	//------------------------  Scheduler Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getAllScheduler
			 - Return Type		:	List<Scheduler> 
			 - Author			:	Preethi
			 - Creation Date	:	29/10/2020
			 - Description		:	updating Scheduler details to database calls dao method getAllScheduler()
			 ********************************************************************************************************/
	
	public List<Scheduler> getAllScheduler() {
		// TODO Auto-generated method stub
		return dao.getAllScheduler();
	}

}
