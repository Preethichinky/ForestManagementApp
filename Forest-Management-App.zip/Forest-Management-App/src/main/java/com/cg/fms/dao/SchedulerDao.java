package com.cg.fms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.cg.fms.dto.Scheduler;
import com.cg.fms.utility.Connection;

public class SchedulerDao implements ISchedulerDao
{

	EntityManagerFactory factory=null;
	EntityManager manager=null;
	EntityTransaction transaction=null;
	
		//------------------------  Scheduler Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	getScheduler(String schedulerId) 
		 - Input Parameters	:	String schedulerId
		 - Return Type		:	Scheduler
		 - Author			:	Preethi
		 - Creation Date	:	28/10/2020
		 - Description		:	Getting Schedulers
		 ********************************************************************************************************/
	
	public Scheduler getScheduler(String schedulerId) 
	{
		// TODO Auto-generated method stub
		
		factory=Connection.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		
		Query query=manager.createQuery("select a from scheduler_details a where a.schedulerId=?1");
		query.setParameter(1,schedulerId);
		List<Scheduler> scheduler=query.getResultList();
		
		return (Scheduler) scheduler;
	}

	//------------------------  Scheduler Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addScheduler(Scheduler scheduler)  
	 - Input Parameters	:	Scheduler scheduler
	 - Return Type		:	true
	 - Author			:	Preethi
	 - Creation Date	:	28/10/2020
	 - Description		:	Adding Schedulers
	 ********************************************************************************************************/
	
	public boolean addScheduler(Scheduler scheduler) 
	{
		// TODO Auto-generated method stub
		factory=Connection.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		if(scheduler!=null) {
			transaction.begin();
			manager.persist(scheduler);
			transaction.commit();
			return true;
		}
		else
		{
			return false;
		}
	}

	//------------------------  Scheduler Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	updateScheduler(Scheduler scheduler)  
		 - Input Parameters	:	Scheduler scheduler
		 - Return Type		:	true
		 - Author			:	Preethi
		 - Creation Date	:	28/10/2020
		 - Description		:	Updating Schedulers
		 ********************************************************************************************************/
	
	public boolean updateScheduler(Scheduler scheduler) 
	{
		// TODO Auto-generated method stub
		factory=Connection.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		
		Scheduler schedulerRecord = manager.find(Scheduler.class, scheduler.schedulerId);
		if(schedulerRecord!=null) 
		{
			transaction.begin();
			schedulerRecord.setSchedulerId(scheduler.schedulerId);
			transaction.commit();
			return true;
		}
		else 
		{
			return false;
		}
	}

	//------------------------  Scheduler Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	deleteScheduler(String schedulerId)   
			 - Input Parameters	:	String schedulerId
			 - Return Type		:	true
			 - Author			:	Preethi
			 - Creation Date	:	28/10/2020
			 - Description		:	Deleting Schedulers
			 ********************************************************************************************************/
	
	public boolean deleteScheduler(String schedulerId) 
	{
		// TODO Auto-generated method stub
		factory=Connection.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
	
		
		Scheduler scheduler=manager.find(Scheduler.class, schedulerId);
		
		transaction.begin();
		manager.remove(scheduler);
		transaction.commit();
		return true;
	}


	//------------------------  Scheduler Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getAllScheduler()   
			 - Input Parameters	:	No
			 - Return Type		:	List<Scheduler>
			 - Author			:	Preethi
			 - Creation Date	:	28/10/2020
			 - Description		:	Getting all Schedulers
			 ********************************************************************************************************/
	
	public List<Scheduler> getAllScheduler() 
	{
		// TODO Auto-generated method stub
		factory=Connection.getFactory();
		manager=factory.createEntityManager();
		String selectQuery ="Select e from Scheduler e ";
		Query query=manager.createQuery(selectQuery);
		List<Scheduler> list=query.getResultList();
		
		return list;
		
	}

}
