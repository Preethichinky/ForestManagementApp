package com.cg.fms.main;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.fms.dto.Scheduler;
import com.cg.fms.exceptions.DataNotFoundException;
import com.cg.fms.service.ISchedulerService;
import com.cg.fms.service.SchedulerService;

public class SchedulerMain 
{
	static String schedulerId;
	static String schedulerName;
	static String schedulerContact;
	public static void main(String args[])
	{
		Scanner scanner = new Scanner(System.in);
		ISchedulerService service = new SchedulerService();
		
		while(true)
		{
			System.out.println("**************************SCHEDULER SERVICES**************************");
			System.out.println("Enter your choice");
			System.out.println("1.To get scheduler details");
			System.out.println("2.To add a new scheduler");
			System.out.println("3.To Update a scheduler ");
			System.out.println("4.To delete a scheduler");
			System.out.println("5.To get all scheduler records");
			System.out.println("****************************************************************************");
			int choice=scanner.nextInt();
			
			
			switch(choice)
			{
					/*
					 * This function will call the service layer method and service layer calls the Dao layer and return the scheduler
					 * object which is populated by the information of the given.
					 */
				case 1:System.out.println("Enter scheduler id");
					   schedulerId=scanner.next();
					   if(schedulerId==null)
					   {
						   throw new DataNotFoundException("enter valid scheduler name");
					   }
					   else
					   {
						   System.out.println(service.getScheduler(schedulerId));
					   }	
					   break;
					   /*
						 * This function will call the service layer method and service layer calls the Dao layer and return the product
						 *  details with respect to schedulerId.
						 */	   
				case 2:System.out.println("Enter scheduler Id");
					   schedulerId=scanner.next();
					   System.out.println("Enter scheduler name");
					   schedulerName=scanner.next();
					   System.out.println("enter the scheduler contact");
					   schedulerContact=scanner.next();
					   Scheduler scheduler=new Scheduler(schedulerId,schedulerName,schedulerContact);
					   if(service.addScheduler(scheduler))
					   {
						   System.out.println("Scheduler added succesfully");
					   }
					   else
					   {
						   throw new DataNotFoundException("Scheduler not added");
					   }
					   break;
					   /*
						 * This function will call the service layer method and service layer calls the Dao layer and return the scheduler
						 * details with updated values
						 */
				case 3:System.out.println("Enter id of the scheduler whose name should be updated");
				   	   schedulerId =scanner.next();
				   	   System.out.println("enter the new name");
				   	   schedulerName=scanner.next();
				   	   Scheduler updateRecord =new Scheduler(schedulerId,schedulerName,schedulerContact);
				   	   if(service.updateScheduler(updateRecord))
				   	   {
				   		   System.out.println("Scheduler's name updated succesfully");
				   	   }
				   	   else
				   	   {
				   		   throw new DataNotFoundException(" Scheduler's name not updated!"); 
				   	   }
				   	   break;
				   	/*
						 * This function will call the service layer method and service layer calls the Dao layer and return the 
						 * deleted scheduler.
						 */
				case 4:System.out.println("Enter id of the scheduler whose record need to be deleted");
					   schedulerId =scanner.next();
					   Scheduler deletescheduler =new Scheduler(schedulerId);
					   try {
						   if(service.deleteScheduler(schedulerId))
						   {
							   System.out.println("Scheduler record removed successfully");
						   }
					   }
					   catch(DataNotFoundException de)
					   {
						   System.out.println("Scheduler record not removed, Try again..");
					   }
					   break;
					/*
					 * This function will call the service layer method and service layer calls the Dao layer and return the 
					 * list of all scheduler present in the database.
					 */
				case 5:List<Scheduler> schedulerrecords =service.getAllScheduler();
				       Iterator<Scheduler> iterator=schedulerrecords.iterator();
				       while(iterator.hasNext())
				       {
				    	   Scheduler record=(Scheduler) iterator.next();
				    	   System.out.println(record);
				       }
				       break;
				case 6:System.out.println("Please enter the valid options");
				       break;
			}
		}
	}
}
